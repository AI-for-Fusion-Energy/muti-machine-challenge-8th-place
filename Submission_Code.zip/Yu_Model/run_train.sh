./train.py --model=lstm --idx=3 --num_layers=2 --batch_size=2048 -k 5 -H 128 --test=0 --epoch=600 -v 3 -s 0.8 -c 3 -K1 10 -K2 2 --slope=0 --block=1 --window_size=64
